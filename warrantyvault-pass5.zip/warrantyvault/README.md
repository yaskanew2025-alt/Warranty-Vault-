# WarrantyVault

Offline-first receipt scanner and warranty/return-window manager (Android 10+, Flutter).

## Build
Push to GitHub; the **Android CI** workflow generates the Android scaffold, patches it
(`tool/patch_android.py`), analyzes, tests, and uploads the APK + AAB.

## Before release
- GitHub Secrets: `KEYSTORE_B64` (base64 of your .jks), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
- Play Console: create a one-time in-app product with id `premium_unlock` ($4.99).
- AdMob: replace the test app id in `tool/patch_android.py` and pass `--dart-define=ADMOB_BANNER_ID=...`.
