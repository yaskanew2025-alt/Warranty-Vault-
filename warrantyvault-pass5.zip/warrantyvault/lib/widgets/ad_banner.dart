import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Banner for free users. Uses Google's test unit unless overridden with
/// --dart-define=ADMOB_BANNER_ID=... at build time (no IDs in source).
class AdBanner extends StatefulWidget {
  const AdBanner({super.key});
  @override
  State<AdBanner> createState() => _AdBannerState();
}

class _AdBannerState extends State<AdBanner> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    try {
      _ad = BannerAd(
        adUnitId: const String.fromEnvironment('ADMOB_BANNER_ID',
            defaultValue: 'ca-app-pub-3940256099942544/6300978111'),
        size: AdSize.banner,
        request: const AdRequest(),
        listener: BannerAdListener(
          onAdLoaded: (_) {
            if (mounted) setState(() => _loaded = true);
          },
          onAdFailedToLoad: (ad, _) => ad.dispose(), // offline: simply no ad
        ),
      )..load();
    } catch (_) {}
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _loaded && _ad != null
      ? SizedBox(height: 50, child: AdWidget(ad: _ad!))
      : const SizedBox.shrink();
}
