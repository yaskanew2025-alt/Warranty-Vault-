/// A saved purchase. Dates are stored as ISO-8601 date strings.
class Purchase {
  final int? id;
  final String productName;
  final String merchant;
  final DateTime purchaseDate;
  final double price;
  final String currency;

  /// Return window: either a duration in days from [returnStart], or an
  /// explicit [returnDeadlineOverride] (manual adjustment wins).
  final int? returnDays;
  final DateTime? returnStart;
  final DateTime? returnDeadlineOverride;

  /// Warranty: months from [warrantyStart], or an explicit override.
  final int? warrantyMonths;
  final DateTime? warrantyStart;
  final DateTime? warrantyEndOverride;

  final String serialNumber;
  final String notes;
  final String? receiptPath;

  /// Extra coverage/repair milestone, e.g. "Extended plan ends".
  final String milestoneLabel;
  final DateTime? milestoneDate;

  const Purchase({
    this.id,
    required this.productName,
    required this.merchant,
    required this.purchaseDate,
    required this.price,
    this.currency = 'USD',
    this.returnDays,
    this.returnStart,
    this.returnDeadlineOverride,
    this.warrantyMonths,
    this.warrantyStart,
    this.warrantyEndOverride,
    this.serialNumber = '',
    this.notes = '',
    this.receiptPath,
    this.milestoneLabel = '',
    this.milestoneDate,
  });

  Purchase copyWith({int? id, String? receiptPath}) => Purchase(
        id: id ?? this.id,
        productName: productName,
        merchant: merchant,
        purchaseDate: purchaseDate,
        price: price,
        currency: currency,
        returnDays: returnDays,
        returnStart: returnStart,
        returnDeadlineOverride: returnDeadlineOverride,
        warrantyMonths: warrantyMonths,
        warrantyStart: warrantyStart,
        warrantyEndOverride: warrantyEndOverride,
        serialNumber: serialNumber,
        notes: notes,
        receiptPath: receiptPath ?? this.receiptPath,
        milestoneLabel: milestoneLabel,
        milestoneDate: milestoneDate,
      );

  static String? _d(DateTime? d) => d?.toIso8601String().substring(0, 10);
  static DateTime? _p(Object? s) => s == null ? null : DateTime.parse(s as String);

  Map<String, Object?> toMap() => {
        'id': id,
        'product_name': productName,
        'merchant': merchant,
        'purchase_date': _d(purchaseDate),
        'price': price,
        'currency': currency,
        'return_days': returnDays,
        'return_start': _d(returnStart),
        'return_override': _d(returnDeadlineOverride),
        'warranty_months': warrantyMonths,
        'warranty_start': _d(warrantyStart),
        'warranty_override': _d(warrantyEndOverride),
        'serial_number': serialNumber,
        'notes': notes,
        'receipt_path': receiptPath,
        'milestone_label': milestoneLabel,
        'milestone_date': _d(milestoneDate),
      };

  factory Purchase.fromMap(Map<String, Object?> m) => Purchase(
        id: m['id'] as int?,
        productName: m['product_name'] as String,
        merchant: m['merchant'] as String,
        purchaseDate: DateTime.parse(m['purchase_date'] as String),
        price: (m['price'] as num).toDouble(),
        currency: (m['currency'] as String?) ?? 'USD',
        returnDays: m['return_days'] as int?,
        returnStart: _p(m['return_start']),
        returnDeadlineOverride: _p(m['return_override']),
        warrantyMonths: m['warranty_months'] as int?,
        warrantyStart: _p(m['warranty_start']),
        warrantyEndOverride: _p(m['warranty_override']),
        serialNumber: (m['serial_number'] as String?) ?? '',
        notes: (m['notes'] as String?) ?? '',
        receiptPath: m['receipt_path'] as String?,
        milestoneLabel: (m['milestone_label'] as String?) ?? '',
        milestoneDate: _p(m['milestone_date']),
      );
}
