import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets/ad_banner.dart';
import 'dashboard.dart';
import 'settings.dart';
import 'timeline.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.state});
  final AppState state;
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: _i, children: [
          DashboardScreen(state: widget.state),
          TimelineScreen(state: widget.state),
          SettingsScreen(state: widget.state),
        ]),
        bottomNavigationBar: ListenableBuilder(
            listenable: widget.state,
            builder: (_, __) => Column(mainAxisSize: MainAxisSize.min, children: [
                  if (!widget.state.isPremium) const AdBanner(),
                  NavigationBar(
                      selectedIndex: _i,
                      onDestinationSelected: (v) => setState(() => _i = v),
                      destinations: const [
                        NavigationDestination(icon: Icon(Icons.shield_outlined), label: 'Vault'),
                        NavigationDestination(icon: Icon(Icons.timeline), label: 'Timeline'),
                        NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
                      ]),
                ])),
      );
}
