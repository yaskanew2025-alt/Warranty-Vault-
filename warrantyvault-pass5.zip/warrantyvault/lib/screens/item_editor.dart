import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import '../app_state.dart';
import '../logic/ocr_parser.dart';
import '../models/purchase.dart';
import 'capture_screen.dart';

class ItemEditorScreen extends StatefulWidget {
  const ItemEditorScreen({super.key, required this.state, this.existing});
  final AppState state;
  final Purchase? existing;
  @override
  State<ItemEditorScreen> createState() => _ItemEditorScreenState();
}

class _ItemEditorScreenState extends State<ItemEditorScreen> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.existing?.productName);
  late final _merchant = TextEditingController(text: widget.existing?.merchant);
  late final _price = TextEditingController(
      text: widget.existing == null ? '' : widget.existing!.price.toStringAsFixed(2));
  late final _retDays = TextEditingController(text: widget.existing?.returnDays?.toString() ?? '30');
  late final _warMonths =
      TextEditingController(text: widget.existing?.warrantyMonths?.toString() ?? '12');
  late final _serial = TextEditingController(text: widget.existing?.serialNumber);
  late final _notes = TextEditingController(text: widget.existing?.notes);
  late final _msLabel = TextEditingController(text: widget.existing?.milestoneLabel);
  late DateTime? _msDate = widget.existing?.milestoneDate;
  late DateTime _date = widget.existing?.purchaseDate ?? DateTime.now();
  late DateTime? _retOverride = widget.existing?.returnDeadlineOverride;
  late DateTime? _warOverride = widget.existing?.warrantyEndOverride;
  String? _receipt; // temp or saved path
  bool _scanning = false, _saving = false;

  @override
  void initState() {
    super.initState();
    _receipt = widget.existing?.receiptPath;
  }

  Future<void> _scan() async {
    final path = await Navigator.push<String>(
        context, MaterialPageRoute(builder: (_) => const CaptureScreen()));
    if (path == null || !mounted) return;
    setState(() {
      _receipt = path;
      _scanning = true;
    });
    final rec = TextRecognizer();
    try {
      final res = await rec.processImage(InputImage.fromFilePath(path));
      final f = parseReceipt(res.text);
      if (res.text.trim().isEmpty ||
          (f.merchant == null && f.date == null && f.total == null)) {
        _msg('Could not read the receipt. Please fill in the details.');
      } else {
        setState(() {
          if (f.merchant != null) _merchant.text = f.merchant!;
          if (f.date != null) _date = f.date!;
          if (f.total != null) _price.text = f.total!.toStringAsFixed(2);
        });
        _msg('Scan complete. Please check the details.');
      }
    } catch (_) {
      _msg('Text recognition failed. You can still enter details manually.');
    } finally {
      await rec.close();
      if (mounted) setState(() => _scanning = false);
    }
  }

  void _msg(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      var path = _receipt;
      if (path != null && path != widget.existing?.receiptPath) {
        final dir = await widget.state.repo.receiptsDir();
        final dest = p.join(dir.path, 'r_${DateTime.now().millisecondsSinceEpoch}.jpg');
        await File(path).copy(dest);
        path = dest;
      }
      int? intOrNull(String s) => int.tryParse(s.trim());
      final item = Purchase(
        id: widget.existing?.id,
        productName: _name.text.trim(),
        merchant: _merchant.text.trim(),
        purchaseDate: _date,
        price: double.parse(_price.text.replaceAll(',', '.')),
        returnDays: intOrNull(_retDays.text),
        warrantyMonths: intOrNull(_warMonths.text),
        returnDeadlineOverride: _retOverride,
        warrantyEndOverride: _warOverride,
        milestoneLabel: _msLabel.text.trim(),
        milestoneDate: _msDate,
        serialNumber: _serial.text.trim(),
        notes: _notes.text.trim(),
        receiptPath: path,
      );
      await widget.state.save(item);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      _msg('Could not save: $e');
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _overrideTile(String label, DateTime? v, void Function(DateTime?) set,
          {String hint = 'Optional: overrides the duration above'}) =>
      ListTile(
        tileColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(label),
        subtitle: Text(hint),
        trailing: v == null
            ? const Icon(Icons.edit_calendar_outlined)
            : Row(mainAxisSize: MainAxisSize.min, children: [
                Text(DateFormat.yMMMd().format(v)),
                IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => set(null))),
              ]),
        onTap: () async {
          final d = await showDatePicker(
              context: context,
              initialDate: v ?? _date,
              firstDate: DateTime(2000),
              lastDate: DateTime(2100));
          if (d != null) setState(() => set(d));
        },
      );

  String? _req(String? v) => (v == null || v.trim().isEmpty) ? 'Required' : null;
  String? _optInt(String? v) =>
      (v == null || v.trim().isEmpty || (int.tryParse(v.trim()) ?? -1) >= 0) ? null : 'Whole number';

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.existing == null ? 'New purchase' : 'Edit purchase')),
        body: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            if (_receipt != null && File(_receipt!).existsSync())
              ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.file(File(_receipt!), height: 160, fit: BoxFit.cover, cacheWidth: 900)),
            const SizedBox(height: 8),
            OutlinedButton.icon(
                onPressed: _scanning ? null : _scan,
                icon: _scanning
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.document_scanner_outlined),
                label: Text(_receipt == null ? 'Scan receipt' : 'Rescan receipt')),
            const SizedBox(height: 16),
            TextFormField(controller: _name, validator: _req, decoration: const InputDecoration(labelText: 'Product name')),
            const SizedBox(height: 12),
            TextFormField(controller: _merchant, validator: _req, decoration: const InputDecoration(labelText: 'Merchant')),
            const SizedBox(height: 12),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              title: const Text('Purchase date'),
              trailing: Text(DateFormat.yMMMd().format(_date)),
              onTap: () async {
                final d = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime.now().add(const Duration(days: 1)));
                if (d != null) setState(() => _date = d);
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
                controller: _price,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) => double.tryParse((v ?? '').replaceAll(',', '.')) == null ? 'Enter a valid price' : null,
                decoration: const InputDecoration(labelText: 'Total price')),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                  child: TextFormField(
                      controller: _retDays,
                      keyboardType: TextInputType.number,
                      validator: _optInt,
                      decoration: const InputDecoration(labelText: 'Return window (days)'))),
              const SizedBox(width: 12),
              Expanded(
                  child: TextFormField(
                      controller: _warMonths,
                      keyboardType: TextInputType.number,
                      validator: _optInt,
                      decoration: const InputDecoration(labelText: 'Warranty (months)'))),
            ]),
            const SizedBox(height: 12),
            _overrideTile('Exact return deadline', _retOverride, (d) => _retOverride = d),
            const SizedBox(height: 12),
            _overrideTile('Exact warranty end', _warOverride, (d) => _warOverride = d),
            const SizedBox(height: 12),
            TextFormField(controller: _msLabel, decoration: const InputDecoration(labelText: 'Coverage milestone (optional)', hintText: 'e.g. Extended plan ends, rebate deadline')),
            const SizedBox(height: 12),
            _overrideTile('Milestone date', _msDate, (d) => _msDate = d, hint: 'Date for the milestone above'),
            const SizedBox(height: 12),
            TextFormField(controller: _serial, decoration: const InputDecoration(labelText: 'Serial number (optional)')),
            const SizedBox(height: 12),
            TextFormField(controller: _notes, maxLines: 3, decoration: const InputDecoration(labelText: 'Retailer / support notes')),
            const SizedBox(height: 20),
            FilledButton(
                onPressed: _saving ? null : _save,
                child: Padding(padding: const EdgeInsets.all(14), child: Text(_saving ? 'Saving…' : 'Save'))),
          ]),
        ),
      );
}
