import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

/// Pops with the captured image path, or null if cancelled/unavailable.
class CaptureScreen extends StatefulWidget {
  const CaptureScreen({super.key});
  @override
  State<CaptureScreen> createState() => _CaptureScreenState();
}

class _CaptureScreenState extends State<CaptureScreen> {
  CameraController? _c;
  String? _problem;
  bool _denied = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final st = await Permission.camera.request();
    if (!st.isGranted) {
      setState(() {
        _denied = true;
        _problem = 'Camera access is off. You can enable it in Settings, or enter details manually.';
      });
      return;
    }
    try {
      final cams = await availableCameras();
      if (cams.isEmpty) throw StateError('No camera found');
      final c = CameraController(cams.first, ResolutionPreset.high, enableAudio: false);
      await c.initialize();
      if (!mounted) return c.dispose();
      setState(() => _c = c);
    } catch (e) {
      if (mounted) setState(() => _problem = 'Camera unavailable: $e');
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  Future<void> _shoot() async {
    try {
      final f = await _c!.takePicture();
      if (mounted) Navigator.pop(context, f.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Capture failed: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: _problem != null
            ? Center(
                child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(_problem!, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      if (_denied) FilledButton(onPressed: openAppSettings, child: const Text('Open Settings')),
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Enter manually')),
                    ])))
            : _c == null
                ? const Center(child: CircularProgressIndicator())
                : Stack(children: [
                    Positioned.fill(child: CameraPreview(_c!)),
                    Positioned(
                        bottom: 32,
                        left: 0,
                        right: 0,
                        child: Center(
                            child: FloatingActionButton.large(
                                onPressed: _shoot, child: const Icon(Icons.camera_alt)))),
                  ]),
      );
}
