import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../app_state.dart';
import '../services/backup_service.dart';
import '../services/export_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.state});
  final AppState state;

  void _msg(BuildContext c, String m) =>
      ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

  Future<String?> _askPassword(BuildContext c, String title) {
    final ctl = TextEditingController();
    return showDialog<String>(
        context: c,
        builder: (d) => AlertDialog(
              title: Text(title),
              content: TextField(controller: ctl, obscureText: true, decoration: const InputDecoration(labelText: 'Backup password')),
              actions: [
                TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
                TextButton(onPressed: () => Navigator.pop(d, ctl.text), child: const Text('OK')),
              ],
            ));
  }

  Future<void> _export(BuildContext c, bool pdf) async {
    if (!state.isPremium) return _msg(c, 'Export is a Premium feature.');
    try {
      pdf ? await ExportService.sharePdf(state.items) : await ExportService.shareCsv(state.items);
    } catch (e) {
      if (c.mounted) _msg(c, 'Export failed: $e');
    }
  }

  Future<void> _backup(BuildContext c) async {
    final pw = await _askPassword(c, 'Set a backup password');
    if (pw == null || pw.length < 6) {
      if (pw != null && c.mounted) _msg(c, 'Use at least 6 characters.');
      return;
    }
    try {
      final f = await BackupService(state.repo).create(pw);
      await Share.shareXFiles([XFile(f.path)]);
    } catch (e) {
      if (c.mounted) _msg(c, 'Backup failed: $e');
    }
  }

  Future<void> _restore(BuildContext c) async {
    final r = await FilePicker.platform.pickFiles();
    final path = r?.files.single.path;
    if (path == null || !c.mounted) return;
    final pw = await _askPassword(c, 'Backup password');
    if (pw == null) return;
    try {
      final n = await BackupService(state.repo).restore(File(path), pw);
      await state.load();
      if (c.mounted) _msg(c, 'Restored $n items.');
    } on FormatException catch (e) {
      if (c.mounted) _msg(c, e.message);
    } catch (e) {
      if (c.mounted) _msg(c, 'Restore failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: state,
      builder: (context, _) => Scaffold(
            appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w700)), backgroundColor: Colors.transparent),
            body: ListView(padding: const EdgeInsets.all(16), children: [
              _section('Premium', [
                ListTile(
                    title: Text(state.isPremium ? 'Premium unlocked' : 'Unlock Premium · ${state.premium.price} once'),
                    subtitle: const Text('Unlimited items, no ads, CSV and PDF export. One-time purchase.'),
                    trailing: state.isPremium ? const Icon(Icons.check_circle, color: Colors.green) : null,
                    onTap: state.isPremium ? null : () async {
                      final e = await state.premium.buy();
                      if (e != null && context.mounted) _msg(context, e);
                    }),
                if (!state.isPremium)
                  ListTile(title: const Text('Restore purchase'), onTap: () async {
                    final e = await state.premium.restore();
                    if (context.mounted) _msg(context, e ?? 'Checking Google Play…');
                  }),
              ]),
              _section('Notifications', [
                SwitchListTile(
                    title: const Text('Deadline reminders'),
                    subtitle: const Text('Local notifications, no account needed'),
                    value: state.notifyEnabled,
                    onChanged: (v) async {
                      final ok = await state.setNotifications(v, state.leadDays);
                      if (!ok && context.mounted) _msg(context, 'Notifications are blocked in Android settings.');
                    }),
                ListTile(
                    title: const Text('Remind me early'),
                    trailing: DropdownButton<int>(
                        value: state.leadDays,
                        items: [for (final d in [0, 1, 3, 7, 14]) DropdownMenuItem(value: d, child: Text(d == 0 ? 'Day of only' : '$d days before'))],
                        onChanged: (v) => v == null ? null : state.setNotifications(state.notifyEnabled, v))),
              ]),
              _section('Local backup & export', [
                const ListTile(subtitle: Text('Backups are encrypted files you save yourself. Nothing is uploaded automatically.')),
                ListTile(leading: const Icon(Icons.save_alt), title: const Text('Create encrypted backup'), onTap: () => _backup(context)),
                ListTile(leading: const Icon(Icons.restore), title: const Text('Restore from backup'), onTap: () => _restore(context)),
                ListTile(leading: const Icon(Icons.table_chart_outlined), title: Text('Export CSV${state.isPremium ? '' : ' (Premium)'}'), onTap: () => _export(context, false)),
                ListTile(leading: const Icon(Icons.picture_as_pdf_outlined), title: Text('Export PDF${state.isPremium ? '' : ' (Premium)'}'), onTap: () => _export(context, true)),
              ]),
              _section('Privacy', const [
                ListTile(subtitle: Text('Purchases and receipt photos are stored only on this device, in an encrypted database. Receipt text is read on-device. No analytics, no accounts. Free-version ads are served by Google AdMob.')),
              ]),
              _section('Data', [
                ListTile(
                    leading: const Icon(Icons.delete_forever, color: Colors.red),
                    title: const Text('Delete all data'),
                    onTap: () async {
                      final ok = await showDialog<bool>(
                          context: context,
                          builder: (d) => AlertDialog(
                                title: const Text('Delete everything?'),
                                content: const Text('All purchases and receipt images will be permanently removed.'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                                  TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete')),
                                ],
                              ));
                      if (ok == true) await state.deleteAll();
                    }),
              ]),
              _section('About', [
                ListTile(
                    title: const Text('WarrantyVault 1.0.0'),
                    subtitle: const Text('Scan a receipt, set return and warranty periods, and get reminded before they end. Dates are estimates; confirm policies with the retailer.')),
              ]),
            ]),
          ));

  Widget _section(String t, List<Widget> kids) => Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(left: 8, bottom: 6), child: Text(t.toUpperCase(), style: const TextStyle(fontSize: 12, color: Colors.grey))),
        Card(child: Column(children: kids)),
      ]));
}
