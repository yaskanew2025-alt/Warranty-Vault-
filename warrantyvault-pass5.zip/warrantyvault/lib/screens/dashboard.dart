import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../app_state.dart';
import '../logic/deadlines.dart';
import '../models/purchase.dart';
import 'item_details.dart';
import 'item_editor.dart';

Color statusColor(DeadlineStatus s) => switch (s) {
      DeadlineStatus.active => const Color(0xFF30B350),
      DeadlineStatus.expiringSoon => const Color(0xFFFF9500),
      DeadlineStatus.expired => const Color(0xFFFF3B30),
      DeadlineStatus.none => Colors.grey,
    };

String describe(String label, DateTime? d, DateTime now) {
  if (d == null) return '$label: not set';
  final n = daysRemaining(d, now);
  if (n < 0) return '$label expired ${-n}d ago';
  return n == 0 ? '$label ends today' : '$label: $n d left';
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.state});
  final AppState state;
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String query = '';
  String filter = 'all';
  String sortBy = 'urgency';

  static const _filters = {
    'all': 'All',
    'returns': 'Return open',
    'warranty': 'Under warranty',
    'expired': 'Expired',
  };

  bool _matches(Purchase p, DateTime now) {
    final r = returnDeadline(p), w = warrantyEnd(p);
    bool live(DateTime? x) => x != null && daysRemaining(x, now) >= 0;
    return switch (filter) {
      'returns' => live(r),
      'warranty' => live(w),
      'expired' => (r != null || w != null) && !live(r) && !live(w),
      _ => true,
    };
  }

  void _sort(List<Purchase> l, DateTime now) {
    switch (sortBy) {
      case 'newest':
        l.sort((a, b) => b.purchaseDate.compareTo(a.purchaseDate));
      case 'price':
        l.sort((a, b) => b.price.compareTo(a.price));
      default:
        l.sort((a, b) => urgencyCompare(a, b, now));
    }
  }

  Future<void> _add() async {
    if (widget.state.atFreeLimit) {
      await showDialog<void>(
          context: context,
          builder: (c) => AlertDialog(
                title: const Text('Free limit reached'),
                content: const Text(
                    'The free version stores up to $freeItemLimit items. Premium (one-time) removes the limit.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(c), child: const Text('Not now')),
                  FilledButton(
                      onPressed: () async {
                        Navigator.pop(c);
                        final e = await widget.state.premium.buy();
                        if (e != null && mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e)));
                        }
                      },
                      child: Text('Upgrade ${widget.state.premium.price}')),
                ],
              ));
      return;
    }
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => ItemEditorScreen(state: widget.state)));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: widget.state,
        builder: (context, _) {
          final s = widget.state;
          final now = DateTime.now();
          final shown = s.items
              .where((p) =>
                  '${p.productName} ${p.merchant}'.toLowerCase().contains(query.toLowerCase()) &&
                  _matches(p, now))
              .toList();
          _sort(shown, now);
          return Scaffold(
            appBar: AppBar(
                title: const Text('Vault', style: TextStyle(fontWeight: FontWeight.w700)),
                backgroundColor: Colors.transparent),
            floatingActionButton: FloatingActionButton.extended(
                onPressed: _add, icon: const Icon(Icons.add), label: const Text('Add purchase')),
            body: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: TextField(
                    decoration: const InputDecoration(
                        hintText: 'Search products or stores', prefixIcon: Icon(Icons.search)),
                    onChanged: (v) => setState(() => query = v)),
              ),
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    for (final f in _filters.entries)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                            label: Text(f.value),
                            selected: filter == f.key,
                            onSelected: (_) => setState(() => filter = f.key)),
                      ),
                    PopupMenuButton<String>(
                      tooltip: 'Sort',
                      icon: const Icon(Icons.sort),
                      onSelected: (v) => setState(() => sortBy = v),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'urgency', child: Text('Soonest deadline')),
                        PopupMenuItem(value: 'newest', child: Text('Newest purchase')),
                        PopupMenuItem(value: 'price', child: Text('Highest price')),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(child: _body(s, shown, now)),
            ]),
          );
        },
      );

  Widget _body(AppState s, List<Purchase> shown, DateTime now) {
    if (s.loading) return const Center(child: CircularProgressIndicator());
    if (s.error != null) {
      return Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(s.error!, textAlign: TextAlign.center),
        const SizedBox(height: 12),
        FilledButton(onPressed: s.load, child: const Text('Retry')),
      ]));
    }
    if (s.items.isEmpty) {
      return const Center(
          child: Padding(
              padding: EdgeInsets.all(32),
              child: Text('Your vault is empty.\nScan a receipt to track returns and warranties.',
                  textAlign: TextAlign.center)));
    }
    if (shown.isEmpty) return const Center(child: Text('No matches'));
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
      itemCount: shown.length,
      itemBuilder: (_, i) {
        final p = shown[i];
        final r = returnDeadline(p), w = warrantyEnd(p);
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ItemDetailsScreen(state: widget.state, purchase: p))),
            title: Text(p.productName, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${p.merchant} · ${DateFormat.yMMMd().format(p.purchaseDate)}'),
                const SizedBox(height: 6),
                _chip(describe('Return', r, now), statusFor(r, now)),
                _chip(describe('Warranty', w, now), statusFor(w, now)),
              ]),
            ),
            trailing: Text(NumberFormat.simpleCurrency(name: p.currency).format(p.price),
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        );
      },
    );
  }

  Widget _chip(String t, DeadlineStatus st) => Row(children: [
        Icon(Icons.circle, size: 9, color: statusColor(st)),
        const SizedBox(width: 6),
        Text(t, style: TextStyle(color: statusColor(st), fontSize: 13)),
      ]);
}
