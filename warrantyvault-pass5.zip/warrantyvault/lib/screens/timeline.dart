import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../app_state.dart';
import '../logic/deadlines.dart';
import 'dashboard.dart' show statusColor;
import 'item_details.dart';

class TimelineScreen extends StatelessWidget {
  const TimelineScreen({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final now = DateTime.now();
        final ev = allEvents(state.items);
        final upcoming = ev.where((e) => daysRemaining(e.date, now) >= 0).toList();
        final past = ev.where((e) => daysRemaining(e.date, now) < 0).toList().reversed.toList();
        Widget tile(DeadlineEvent e) {
          final n = daysRemaining(e.date, now);
          final st = statusFor(e.date, now);
          return ListTile(
            onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => ItemDetailsScreen(state: state, purchase: e.purchase))),
            leading: Icon(switch (e.kind) {
              DeadlineKind.returnWindow => Icons.assignment_return_outlined,
              DeadlineKind.warranty => Icons.verified_user_outlined,
              DeadlineKind.milestone => Icons.build_circle_outlined,
            }, color: statusColor(st)),
            title: Text(e.purchase.productName),
            subtitle: Text('${eventLabel(e)} · ${DateFormat.yMMMd().format(e.date)}'),
            trailing: Text(n < 0 ? 'Expired' : n == 0 ? 'Today' : '$n d',
                style: TextStyle(color: statusColor(st), fontWeight: FontWeight.w600)),
          );
        }
        Widget header(String t) => Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
            child: Text(t, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18)));
        return Scaffold(
          appBar: AppBar(title: const Text('Timeline', style: TextStyle(fontWeight: FontWeight.w700)), backgroundColor: Colors.transparent),
          body: ev.isEmpty
              ? const Center(child: Text('No deadlines yet.\nAdd a purchase with a return or warranty period.', textAlign: TextAlign.center))
              : ListView(children: [
                  header('Upcoming'),
                  if (upcoming.isEmpty) const ListTile(title: Text('Nothing upcoming')),
                  for (final e in upcoming) tile(e),
                  if (past.isNotEmpty) header('Expired'),
                  for (final e in past) tile(e),
                  const SizedBox(height: 24),
                ]),
        );
      });
}
