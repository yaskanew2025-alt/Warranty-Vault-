import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../app_state.dart';
import '../logic/deadlines.dart';
import '../models/purchase.dart';
import 'dashboard.dart' show describe;
import 'item_editor.dart';

class ItemDetailsScreen extends StatelessWidget {
  const ItemDetailsScreen({super.key, required this.state, required this.purchase});
  final AppState state;
  final Purchase purchase;

  @override
  Widget build(BuildContext context) {
    // Re-read from state so edits show immediately.
    final p = state.items.firstWhere((e) => e.id == purchase.id, orElse: () => purchase);
    final now = DateTime.now();
    final fmt = DateFormat.yMMMMd();
    final r = returnDeadline(p), w = warrantyEnd(p);
    Widget row(String k, String v) => ListTile(title: Text(k), trailing: Text(v), dense: true);
    return Scaffold(
      appBar: AppBar(title: Text(p.productName), actions: [
        IconButton(
            tooltip: 'Edit',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ItemEditorScreen(state: state, existing: p)))),
        IconButton(
            tooltip: 'Delete',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await showDialog<bool>(
                  context: context,
                  builder: (c) => AlertDialog(
                        title: const Text('Delete item?'),
                        content: const Text('This permanently removes the purchase and its receipt image.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
                          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
                        ],
                      ));
              if (ok == true) {
                await state.delete(p);
                if (context.mounted) Navigator.pop(context);
              }
            }),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (p.receiptPath != null && File(p.receiptPath!).existsSync())
          GestureDetector(
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => _Viewer(path: p.receiptPath!))),
            child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.file(File(p.receiptPath!), height: 220, fit: BoxFit.cover,
                    cacheWidth: 1200)),
          )
        else
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No receipt image saved'))),
        const SizedBox(height: 12),
        Card(
            child: Column(children: [
          row('Merchant', p.merchant),
          row('Purchased', fmt.format(p.purchaseDate)),
          row('Price', NumberFormat.simpleCurrency(name: p.currency).format(p.price)),
          row('Return deadline', r == null ? 'Not set' : fmt.format(r)),
          row('Return status', describe('Return', r, now)),
          row('Warranty ends', w == null ? 'Not set' : fmt.format(w)),
          row('Warranty status', describe('Warranty', w, now)),
          if (p.milestoneDate != null)
            row(p.milestoneLabel.isEmpty ? 'Coverage milestone' : p.milestoneLabel, fmt.format(p.milestoneDate!)),
          row('Serial number', p.serialNumber.isEmpty ? '—' : p.serialNumber),
        ])),
        if (p.notes.isNotEmpty)
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(p.notes))),
      ]),
    );
  }
}

class _Viewer extends StatelessWidget {
  const _Viewer({required this.path});
  final String path;
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: InteractiveViewer(
            minScale: 1, maxScale: 6, child: Center(child: Image.file(File(path)))),
      );
}
