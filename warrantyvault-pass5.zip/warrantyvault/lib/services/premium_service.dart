import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// One-time, non-consumable $4.99 unlock. Product id must be created in
/// Play Console. Entitlement is cached locally so it works offline.
class PremiumService {
  PremiumService(this.onChange);
  static const productId = 'premium_unlock';
  final void Function(bool) onChange;
  StreamSubscription<List<PurchaseDetails>>? _sub;
  String price = r'$4.99';

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    onChange(prefs.getBool('premium') ?? false);
    try {
      _sub = InAppPurchase.instance.purchaseStream.listen((list) async {
        for (final p in list) {
          final ok = p.status == PurchaseStatus.purchased || p.status == PurchaseStatus.restored;
          if (p.productID == productId && ok) {
            await prefs.setBool('premium', true);
            onChange(true);
          }
          if (p.pendingCompletePurchase) await InAppPurchase.instance.completePurchase(p);
        }
      });
    } catch (_) {}
  }

  /// Returns an error message, or null if the purchase sheet was launched.
  Future<String?> buy() async {
    try {
      final iap = InAppPurchase.instance;
      if (!await iap.isAvailable()) return 'Google Play is unavailable. Check your connection and try again.';
      final r = await iap.queryProductDetails({productId});
      if (r.productDetails.isEmpty) return 'Premium is not available right now.';
      price = r.productDetails.first.price;
      await iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: r.productDetails.first));
      return null;
    } catch (e) {
      return 'Purchase failed: $e';
    }
  }

  Future<String?> restore() async {
    try {
      await InAppPurchase.instance.restorePurchases();
      return null;
    } catch (e) {
      return 'Restore failed: $e';
    }
  }

  void dispose() => _sub?.cancel();
}
