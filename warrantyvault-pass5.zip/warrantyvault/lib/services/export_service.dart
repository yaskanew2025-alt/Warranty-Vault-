import 'dart:io';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../logic/deadlines.dart';
import '../models/purchase.dart';

final _df = DateFormat('yyyy-MM-dd');
String _d(DateTime? d) => d == null ? '' : _df.format(d);
const _header = ['Product', 'Merchant', 'Purchase date', 'Price', 'Return deadline', 'Warranty end', 'Serial', 'Notes'];
List<List<String>> _rows(List<Purchase> items) => [
      for (final p in items)
        [p.productName, p.merchant, _d(p.purchaseDate), p.price.toStringAsFixed(2),
         _d(returnDeadline(p)), _d(warrantyEnd(p)), p.serialNumber, p.notes]
    ];

String buildCsv(List<Purchase> items) =>
    const ListToCsvConverter().convert([_header, ..._rows(items)]);

class ExportService {
  static Future<void> shareCsv(List<Purchase> items) async {
    final f = File('${(await getTemporaryDirectory()).path}/warrantyvault.csv');
    await f.writeAsString(buildCsv(items));
    await Share.shareXFiles([XFile(f.path)]);
  }

  static Future<void> sharePdf(List<Purchase> items) async {
    final doc = pw.Document()
      ..addPage(pw.MultiPage(
          build: (_) => [
                pw.Header(level: 0, text: 'WarrantyVault export'),
                pw.TableHelper.fromTextArray(
                    headers: _header.sublist(0, 6),
                    data: _rows(items).map((r) => r.sublist(0, 6)).toList(),
                    cellStyle: const pw.TextStyle(fontSize: 8),
                    headerStyle: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
              ]));
    final f = File('${(await getTemporaryDirectory()).path}/warrantyvault.pdf');
    await f.writeAsBytes(await doc.save());
    await Share.shareXFiles([XFile(f.path)]);
  }
}
