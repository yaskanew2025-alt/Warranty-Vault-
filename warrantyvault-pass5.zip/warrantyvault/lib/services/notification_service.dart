import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../logic/deadlines.dart';
import '../models/purchase.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation(await FlutterTimezone.getLocalTimezone()));
    await _plugin.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  }

  /// Returns false if the user denied the notification permission.
  static Future<bool> requestPermission() async {
    final a = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return await a?.requestNotificationsPermission() ?? true;
  }

  /// Rebuilds all alarms: one reminder [leadDays] before and one on the day
  /// (9:00 local). Inexact alarms avoid the exact-alarm permission.
  static Future<void> reschedule(List<Purchase> items,
      {required bool enabled, required int leadDays}) async {
    await _plugin.cancelAll();
    if (!enabled) return;
    const details = NotificationDetails(
        android: AndroidNotificationDetails('deadlines', 'Deadline reminders',
            channelDescription: 'Return and warranty deadlines',
            importance: Importance.defaultImportance));
    final now = tz.TZDateTime.now(tz.local);
    var id = 0;
    for (final e in allEvents(items)) {
      final what = eventLabel(e);
      final due = tz.TZDateTime(tz.local, e.date.year, e.date.month, e.date.day, 9);
      final times = {
        if (leadDays > 0) due.subtract(Duration(days: leadDays)):
            '$what: ${e.purchase.productName} in $leadDays days',
        due: '$what: ${e.purchase.productName} is today',
      };
      for (final t in times.entries) {
        if (!t.key.isAfter(now) || id >= 400) continue;
        await _plugin.zonedSchedule(id++, 'WarrantyVault', t.value, t.key, details,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            uiLocalNotificationDateInterpretation:
                UILocalNotificationDateInterpretation.absoluteTime);
      }
    }
  }
}
