import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pointycastle/export.dart';
import '../data/purchase_repository.dart';
import '../models/purchase.dart';

/// Local, password-encrypted backup file (AES-256-GCM, PBKDF2-SHA256).
/// Nothing is uploaded; the user chooses where to save the file.
class BackupService {
  BackupService(this.repo);
  final PurchaseRepository repo;

  static enc.Key _key(String pw, Uint8List salt) {
    final d = PBKDF2KeyDerivator(HMac(SHA256Digest(), 64))
      ..init(Pbkdf2Parameters(salt, 100000, 32));
    return enc.Key(d.process(Uint8List.fromList(utf8.encode(pw))));
  }

  Future<File> create(String password) async {
    final items = await repo.all();
    final zip = Archive();
    final records = <Map<String, Object?>>[];
    for (final it in items) {
      final m = it.toMap();
      final path = it.receiptPath;
      if (path != null && File(path).existsSync()) {
        final name = p.basename(path);
        final bytes = await File(path).readAsBytes();
        zip.addFile(ArchiveFile('receipts/$name', bytes.length, bytes));
        m['receipt_path'] = name;
      } else {
        m['receipt_path'] = null;
      }
      records.add(m);
    }
    final json = utf8.encode(jsonEncode(records));
    zip.addFile(ArchiveFile('data.json', json.length, json));
    final plain = Uint8List.fromList(ZipEncoder().encode(zip)!);
    final r = Random.secure();
    final salt = Uint8List.fromList(List.generate(16, (_) => r.nextInt(256)));
    final iv = enc.IV.fromSecureRandom(12);
    final ct = enc.Encrypter(enc.AES(_key(password, salt), mode: enc.AESMode.gcm)).encryptBytes(plain, iv: iv);
    final out = File(p.join((await getTemporaryDirectory()).path,
        'warrantyvault-${DateTime.now().millisecondsSinceEpoch}.wvbackup'));
    return out.writeAsBytes([...salt, ...iv.bytes, ...ct.bytes]);
  }

  /// Merges the backup into the vault. Throws FormatException on a wrong
  /// password or a corrupt file. Returns the number of items restored.
  Future<int> restore(File file, String password) async {
    final all = await file.readAsBytes();
    if (all.length < 45) throw const FormatException('Not a WarrantyVault backup');
    try {
      final salt = Uint8List.fromList(all.sublist(0, 16));
      final iv = enc.IV(Uint8List.fromList(all.sublist(16, 28)));
      final plain = enc.Encrypter(enc.AES(_key(password, salt), mode: enc.AESMode.gcm))
          .decryptBytes(enc.Encrypted(Uint8List.fromList(all.sublist(28))), iv: iv);
      final zip = ZipDecoder().decodeBytes(plain);
      final data = zip.findFile('data.json')!;
      final records = jsonDecode(utf8.decode(data.content as List<int>)) as List;
      final dir = await repo.receiptsDir();
      var n = 0;
      for (final raw in records) {
        final m = Map<String, Object?>.from(raw as Map)..remove('id'); // never overwrite existing rows
        final name = m['receipt_path'] as String?;
        m['receipt_path'] = null;
        if (name != null) {
          final f = zip.findFile('receipts/$name');
          if (f != null) {
            final dest = p.join(dir.path, 'r_${DateTime.now().microsecondsSinceEpoch}_$n.jpg');
            await File(dest).writeAsBytes(f.content as List<int>);
            m['receipt_path'] = dest;
          }
        }
        await repo.save(Purchase.fromMap(m).copyWith(id: null));
        n++;
      }
      return n;
    } catch (_) {
      throw const FormatException('Wrong password or damaged backup file');
    }
  }
}
