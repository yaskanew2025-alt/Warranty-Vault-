import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'app_state.dart';
import 'data/purchase_repository.dart';
import 'screens/home_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  final state = AppState(PurchaseRepository())..init();
  runApp(WarrantyVaultApp(state: state));
}

class WarrantyVaultApp extends StatelessWidget {
  const WarrantyVaultApp({super.key, required this.state});
  final AppState state;
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'WarrantyVault',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF0A84FF),
          scaffoldBackgroundColor: const Color(0xFFF2F2F7),
          cardTheme: CardThemeData(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
          inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
        ),
        home: HomeShell(state: state),
      );
}
