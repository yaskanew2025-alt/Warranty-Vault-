import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/purchase_repository.dart';
import 'models/purchase.dart';
import 'services/notification_service.dart';
import 'services/premium_service.dart';

const freeItemLimit = 8;

class AppState extends ChangeNotifier {
  AppState(this.repo) {
    premium = PremiumService((v) {
      isPremium = v;
      notifyListeners();
    });
  }
  final PurchaseRepository repo;
  late final PremiumService premium;
  List<Purchase> items = [];
  bool loading = true;
  String? error;
  bool isPremium = false;
  bool notifyEnabled = true;
  int leadDays = 3;

  bool get atFreeLimit => !isPremium && items.length >= freeItemLimit;

  Future<void> init() async {
    final sp = await SharedPreferences.getInstance();
    notifyEnabled = sp.getBool('notify') ?? true;
    leadDays = sp.getInt('lead') ?? 3;
    try {
      await NotificationService.init();
      if (notifyEnabled) await NotificationService.requestPermission();
    } catch (_) {}
    await premium.init();
    await load();
  }

  Future<bool> setNotifications(bool enabled, int lead) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('notify', enabled);
    await sp.setInt('lead', lead);
    notifyEnabled = enabled;
    leadDays = lead;
    var granted = true;
    try {
      if (enabled) granted = await NotificationService.requestPermission();
    } catch (_) {}
    await _reschedule();
    notifyListeners();
    return granted;
  }

  Future<void> _reschedule() async {
    try {
      await NotificationService.reschedule(items, enabled: notifyEnabled, leadDays: leadDays);
    } catch (_) {}
  }

  Future<void> load() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      items = await repo.all();
      await _reschedule();
    } catch (e) {
      error = 'Could not open your vault: $e';
    }
    loading = false;
    notifyListeners();
  }

  Future<void> save(Purchase p) async {
    await repo.save(p);
    await load();
  }

  Future<void> delete(Purchase p) async {
    await repo.delete(p);
    await load();
  }

  Future<void> deleteAll() async {
    for (final p in List.of(items)) {
      await repo.delete(p);
    }
    await load();
  }
}
