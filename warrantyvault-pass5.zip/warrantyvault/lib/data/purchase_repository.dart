import 'dart:io';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';
import 'dart:math';
import 'dart:convert';
import '../models/purchase.dart';

/// Encrypted local store (SQLCipher). The passphrase is generated once and
/// kept in the Android Keystore via flutter_secure_storage.
class PurchaseRepository {
  Database? _db;
  static const _keyName = 'db_key_v1';

  Future<String> _passphrase() async {
    const s = FlutterSecureStorage();
    var k = await s.read(key: _keyName);
    if (k == null) {
      final r = Random.secure();
      k = base64Url.encode(List<int>.generate(32, (_) => r.nextInt(256)));
      await s.write(key: _keyName, value: k);
    }
    return k;
  }

  Future<Database> get db async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'vault.db');
    _db = await openDatabase(path, password: await _passphrase(), version: 2,
        onUpgrade: (d, o, n) async {
          if (o < 2) {
            await d.execute('ALTER TABLE purchases ADD COLUMN milestone_label TEXT');
            await d.execute('ALTER TABLE purchases ADD COLUMN milestone_date TEXT');
          }
        },
        onCreate: (d, _) => d.execute('''
CREATE TABLE purchases(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_name TEXT NOT NULL, merchant TEXT NOT NULL,
  purchase_date TEXT NOT NULL, price REAL NOT NULL, currency TEXT,
  return_days INTEGER, return_start TEXT, return_override TEXT,
  warranty_months INTEGER, warranty_start TEXT, warranty_override TEXT,
  serial_number TEXT, notes TEXT, receipt_path TEXT,
  milestone_label TEXT, milestone_date TEXT)'''));
    return _db!;
  }

  Future<List<Purchase>> all() async =>
      (await (await db).query('purchases')).map(Purchase.fromMap).toList();

  Future<int> count() async => Sqflite.firstIntValue(
      await (await db).rawQuery('SELECT COUNT(*) FROM purchases')) ?? 0;

  Future<Purchase> save(Purchase item) async {
    final d = await db;
    if (item.id == null) {
      final id = await d.insert('purchases', item.toMap()..remove('id'));
      return item.copyWith(id: id);
    }
    await d.update('purchases', item.toMap(), where: 'id=?', whereArgs: [item.id]);
    return item;
  }

  /// Removes the row AND the receipt image file.
  Future<void> delete(Purchase item) async {
    if (item.receiptPath != null) {
      final f = File(item.receiptPath!);
      if (await f.exists()) await f.delete();
    }
    await (await db).delete('purchases', where: 'id=?', whereArgs: [item.id]);
  }

  Future<Directory> receiptsDir() async {
    final base = await getApplicationDocumentsDirectory();
    return Directory(p.join(base.path, 'receipts')).create(recursive: true);
  }
}
