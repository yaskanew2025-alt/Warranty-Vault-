import '../models/purchase.dart';

enum DeadlineKind { returnWindow, warranty, milestone }

enum DeadlineStatus { none, active, expiringSoon, expired }

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

/// Adds calendar months, clamping the day (Jan 31 + 1 month = Feb 28/29).
DateTime addMonths(DateTime d, int months) {
  final total = d.month - 1 + months;
  final year = d.year + total ~/ 12;
  final month = total % 12 + 1;
  final lastDay = DateTime(year, month + 1, 0).day;
  return DateTime(year, month, d.day > lastDay ? lastDay : d.day);
}

DateTime? returnDeadline(Purchase p) {
  if (p.returnDeadlineOverride != null) return dateOnly(p.returnDeadlineOverride!);
  if (p.returnDays == null) return null;
  final start = dateOnly(p.returnStart ?? p.purchaseDate);
  return DateTime(start.year, start.month, start.day + p.returnDays!);
}

DateTime? warrantyEnd(Purchase p) {
  if (p.warrantyEndOverride != null) return dateOnly(p.warrantyEndOverride!);
  if (p.warrantyMonths == null) return null;
  return addMonths(dateOnly(p.warrantyStart ?? p.purchaseDate), p.warrantyMonths!);
}

/// Whole days from [now] to [deadline]; negative when past. A deadline is
/// still valid through the end of its own day.
int daysRemaining(DateTime deadline, DateTime now) =>
    dateOnly(deadline).difference(dateOnly(now)).inDays;

DeadlineStatus statusFor(DateTime? deadline, DateTime now, {int soonDays = 14}) {
  if (deadline == null) return DeadlineStatus.none;
  final d = daysRemaining(deadline, now);
  if (d < 0) return DeadlineStatus.expired;
  if (d <= soonDays) return DeadlineStatus.expiringSoon;
  return DeadlineStatus.active;
}

class DeadlineEvent {
  final Purchase purchase;
  final DeadlineKind kind;
  final DateTime date;
  const DeadlineEvent(this.purchase, this.kind, this.date);
}

/// All deadlines across purchases, soonest first (for dashboard + timeline).
List<DeadlineEvent> allEvents(List<Purchase> items) {
  final out = <DeadlineEvent>[];
  for (final p in items) {
    final r = returnDeadline(p);
    final w = warrantyEnd(p);
    if (r != null) out.add(DeadlineEvent(p, DeadlineKind.returnWindow, r));
    if (w != null) out.add(DeadlineEvent(p, DeadlineKind.warranty, w));
    final ms = p.milestoneDate;
    if (ms != null) out.add(DeadlineEvent(p, DeadlineKind.milestone, dateOnly(ms)));
  }
  out.sort((a, b) => a.date.compareTo(b.date));
  return out;
}

/// Sort key for the dashboard: nearest non-expired deadline first,
/// then items with none, then fully expired.
int urgencyCompare(Purchase a, Purchase b, DateTime now) {
  int rank(Purchase p) {
    final ds = [returnDeadline(p), warrantyEnd(p)]
        .whereType<DateTime>()
        .map((d) => daysRemaining(d, now))
        .toList();
    final live = ds.where((d) => d >= 0).toList()..sort();
    if (live.isNotEmpty) return live.first;
    return ds.isEmpty ? 100000 : 200000;
  }

  return rank(a).compareTo(rank(b));
}

String eventLabel(DeadlineEvent e) => switch (e.kind) {
      DeadlineKind.returnWindow => 'Return deadline',
      DeadlineKind.warranty => 'Warranty ends',
      DeadlineKind.milestone =>
        e.purchase.milestoneLabel.isEmpty ? 'Coverage milestone' : e.purchase.milestoneLabel,
    };
