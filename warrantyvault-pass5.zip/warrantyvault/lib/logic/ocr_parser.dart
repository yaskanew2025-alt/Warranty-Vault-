/// Heuristic receipt text parser. Results are suggestions the user edits.
class ReceiptFields {
  final String? merchant;
  final DateTime? date;
  final double? total;
  const ReceiptFields({this.merchant, this.date, this.total});
}

const _months = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
final _amount = RegExp(r'(\d{1,3}(?:,\d{3})*|\d+)[.,](\d{2})\b');

DateTime? _valid(int y, int m, int d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return null;
  final dt = DateTime(y, m, d);
  return dt.month == m ? dt : null;
}

DateTime? parseDate(String text) {
  for (final m in RegExp(r'\b(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\b').allMatches(text)) {
    final d = _valid(int.parse(m[1]!), int.parse(m[2]!), int.parse(m[3]!));
    if (d != null) return d;
  }
  for (final m in RegExp(r'\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})\b').allMatches(text)) {
    final a = int.parse(m[1]!), b = int.parse(m[2]!), y = int.parse(m[3]!);
    final d = a > 12 ? _valid(y, b, a) : _valid(y, a, b); // default MM/DD
    if (d != null) return d;
  }
  final named = RegExp(r'\b([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})\b');
  for (final m in named.allMatches(text)) {
    final mi = _months.indexOf(m[1]!.toLowerCase());
    if (mi >= 0) {
      final d = _valid(int.parse(m[3]!), mi + 1, int.parse(m[2]!));
      if (d != null) return d;
    }
  }
  return null;
}

double? _toAmount(RegExpMatch m) =>
    double.tryParse('${m[1]!.replaceAll(',', '')}.${m[2]}');

double? parseTotal(List<String> lines) {
  for (final l in lines.reversed) {
    final low = l.toLowerCase();
    if (low.contains('total') && !low.contains('subtotal') && !low.contains('sub total')) {
      final ms = _amount.allMatches(l).toList();
      if (ms.isNotEmpty) return _toAmount(ms.last);
    }
  }
  double? best;
  for (final l in lines) {
    for (final m in _amount.allMatches(l)) {
      final v = _toAmount(m);
      if (v != null && (best == null || v > best)) best = v;
    }
  }
  return best;
}

String? parseMerchant(List<String> lines) {
  for (final l in lines.take(8)) {
    final t = l.trim();
    if (t.length < 3 || !RegExp(r'[A-Za-z]{3}').hasMatch(t)) continue;
    if (parseDate(t) != null || _amount.hasMatch(t)) continue;
    if (RegExp(r'^(tel|phone|www|http|receipt|invoice)', caseSensitive: false).hasMatch(t)) continue;
    return t;
  }
  return null;
}

ReceiptFields parseReceipt(String text) {
  final lines = text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  return ReceiptFields(
      merchant: parseMerchant(lines), date: parseDate(text), total: parseTotal(lines));
}
