"""Patches the generated Android project: permissions, notification receivers,
AdMob test app id, no cloud auto-backup, minSdk 29 (Android 10), desugaring,
and release signing from env vars."""
import glob, re, sys
man = 'android/app/src/main/AndroidManifest.xml'
s = open(man).read()
if 'POST_NOTIFICATIONS' not in s:
    perms = ('<uses-permission android:name="android.permission.CAMERA"/>\n'
             '<uses-permission android:name="android.permission.INTERNET"/>\n'
             '<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
             '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>\n'
             '<uses-feature android:name="android.hardware.camera" android:required="false"/>\n')
    s = s.replace('<application', perms + '<application android:allowBackup="false"', 1)
    extra = ('\n<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" '
             'android:value="ca-app-pub-3940256099942544~3347511713"/>'
             '\n<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>'
             '\n<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">'
             '<intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/>'
             '<action android:name="android.intent.action.MY_PACKAGE_REPLACED"/></intent-filter></receiver>')
    s = re.sub(r'(<application[^>]*>)', lambda m: m.group(1) + extra, s, count=1)
    open(man, 'w').write(s)
g = glob.glob('android/app/build.gradle.kts')
if not g:
    sys.exit('Expected android/app/build.gradle.kts (Kotlin DSL)')
p = g[0]; b = open(p).read()
b = re.sub(r'minSdk\s*=\s*[^\n]+', 'minSdk = 29', b)
if 'isCoreLibraryDesugaringEnabled' not in b:
    b = b.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
    b += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")\n}\n'
if 'create("release")' not in b:
    sign = '''signingConfigs {
        create("release") {
            val ks = file("upload.jks")
            if (ks.exists()) {
                storeFile = ks
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {'''
    b = b.replace('buildTypes {', sign, 1)
    b = b.replace('signingConfig = signingConfigs.getByName("debug")',
        'signingConfig = if (file("upload.jks").exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")')
open(p, 'w').write(b)
