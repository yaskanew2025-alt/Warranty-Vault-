import 'package:flutter_test/flutter_test.dart';
import 'package:warranty_vault/logic/ocr_parser.dart';

void main() {
  const text = 'BEST GADGETS\n123 Main St\nTel 555-1234\nDate: 03/14/2026\nSubtotal 90.00\nTax 7.20\nTOTAL \$97.20\n';
  test('parses merchant, date, total', () {
    final f = parseReceipt(text);
    expect(f.merchant, 'BEST GADGETS');
    expect(f.date, DateTime(2026, 3, 14));
    expect(f.total, 97.20);
  });
  test('day-first and ISO dates', () {
    expect(parseDate('25/12/2025'), DateTime(2025, 12, 25));
    expect(parseDate('2026-02-30'), isNull);
    expect(parseDate('Mar 5, 2026'), DateTime(2026, 3, 5));
  });
  test('empty text yields nulls', () {
    final f = parseReceipt('');
    expect(f.merchant, isNull);
    expect(f.total, isNull);
  });
}
