import 'package:flutter_test/flutter_test.dart';
import 'package:warranty_vault/models/purchase.dart';
import 'package:warranty_vault/services/export_service.dart';

void main() {
  test('csv has header, computed dates and escapes commas', () {
    final csv = buildCsv([
      Purchase(productName: 'TV, 55"', merchant: 'Shop', purchaseDate: DateTime(2026, 1, 10),
          price: 499.5, returnDays: 30, warrantyMonths: 12)
    ]);
    expect(csv.split('\n').first, startsWith('Product,Merchant'));
    expect(csv, contains('2026-02-09'));
    expect(csv, contains('2027-01-10'));
    expect(csv, contains('499.50'));
    expect(csv, contains('"TV, 55"""'));
  });
}
