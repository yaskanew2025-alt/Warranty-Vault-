import 'package:flutter_test/flutter_test.dart';
import 'package:warranty_vault/logic/deadlines.dart';
import 'package:warranty_vault/models/purchase.dart';

Purchase make({int? rd, int? wm, DateTime? ro, DateTime? wo}) => Purchase(
    productName: 'TV', merchant: 'Shop', purchaseDate: DateTime(2026, 1, 31),
    price: 100, returnDays: rd, warrantyMonths: wm,
    returnDeadlineOverride: ro, warrantyEndOverride: wo);

void main() {
  test('addMonths clamps to month end', () {
    expect(addMonths(DateTime(2026, 1, 31), 1), DateTime(2026, 2, 28));
    expect(addMonths(DateTime(2024, 1, 31), 1), DateTime(2024, 2, 29));
    expect(addMonths(DateTime(2026, 11, 15), 3), DateTime(2027, 2, 15));
  });
  test('return deadline from days and override', () {
    expect(returnDeadline(make(rd: 30)), DateTime(2026, 3, 2));
    expect(returnDeadline(make(rd: 30, ro: DateTime(2026, 5, 1))), DateTime(2026, 5, 1));
    expect(returnDeadline(make()), isNull);
  });
  test('warranty end from months and override', () {
    expect(warrantyEnd(make(wm: 12)), DateTime(2027, 1, 31));
    expect(warrantyEnd(make(wm: 12, wo: DateTime(2030, 1, 1))), DateTime(2030, 1, 1));
  });
  test('status boundaries', () {
    final now = DateTime(2026, 10, 6, 23, 59);
    expect(statusFor(DateTime(2026, 10, 6), now), DeadlineStatus.expiringSoon);
    expect(statusFor(DateTime(2026, 10, 5), now), DeadlineStatus.expired);
    expect(statusFor(DateTime(2026, 12, 1), now), DeadlineStatus.active);
    expect(statusFor(null, now), DeadlineStatus.none);
  });
  test('events sorted soonest first', () {
    final e = allEvents([make(rd: 30, wm: 12)]);
    expect(e.first.kind, DeadlineKind.returnWindow);
    expect(e.length, 2);
  });
  test('milestone appears in events with label', () {
    final p = Purchase(productName: 'Fridge', merchant: 'M', purchaseDate: DateTime(2026, 1, 1),
        price: 1, milestoneLabel: 'Extended plan ends', milestoneDate: DateTime(2028, 1, 1));
    final e = allEvents([p]);
    expect(e.single.kind, DeadlineKind.milestone);
    expect(eventLabel(e.single), 'Extended plan ends');
  });
}
