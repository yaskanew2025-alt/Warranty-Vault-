import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:warranty_vault/app_state.dart';
import 'package:warranty_vault/data/purchase_repository.dart';
import 'package:warranty_vault/models/purchase.dart';
import 'package:warranty_vault/screens/dashboard.dart';

class FakeRepo extends PurchaseRepository {
  FakeRepo(this.data);
  final List<Purchase> data;
  @override
  Future<List<Purchase>> all() async => data;
}

void main() {
  final now = DateTime.now();
  final laptop = Purchase(
      productName: 'Laptop', merchant: 'TechMart',
      purchaseDate: now.subtract(const Duration(days: 10)), price: 999,
      returnDays: 30, warrantyMonths: 12);
  final phone = Purchase(
      productName: 'Phone', merchant: 'GadgetCo',
      purchaseDate: now.subtract(const Duration(days: 900)), price: 499,
      returnDays: 30, warrantyMonths: 12);

  Future<AppState> pump(WidgetTester t, List<Purchase> data) async {
    final state = AppState(FakeRepo(data));
    await state.load();
    await t.pumpWidget(MaterialApp(home: DashboardScreen(state: state)));
    return state;
  }

  testWidgets('lists items, searches and filters', (t) async {
    await pump(t, [laptop, phone]);
    expect(find.text('Laptop'), findsOneWidget);
    expect(find.text('Phone'), findsOneWidget);

    await t.tap(find.text('Expired'));
    await t.pump();
    expect(find.text('Laptop'), findsNothing);
    expect(find.text('Phone'), findsOneWidget);

    await t.tap(find.text('All'));
    await t.enterText(find.byType(TextField), 'tech');
    await t.pump();
    expect(find.text('Laptop'), findsOneWidget);
    expect(find.text('Phone'), findsNothing);
  });

  testWidgets('shows empty state', (t) async {
    await pump(t, []);
    expect(find.textContaining('Your vault is empty'), findsOneWidget);
  });
}
